# Special feature: password requirements
import os

from cs50 import SQL
from flask import Flask, flash, redirect, render_template, request, session
from flask_session import Session
from tempfile import mkdtemp
from werkzeug.security import check_password_hash, generate_password_hash

from helpers import apology, login_required, lookup, usd

# Configure application
app = Flask(__name__)

# Custom filter
app.jinja_env.filters["usd"] = usd

# Configure session to use filesystem (instead of signed cookies)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)

# Configure CS50 Library to use SQLite database
db = SQL("sqlite:///finance.db")

# Make sure API key is set
if not os.environ.get("API_KEY"):
    raise RuntimeError("API_KEY not set")


@app.after_request
def after_request(response):
    """Ensure responses aren't cached"""
    response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
    response.headers["Expires"] = 0
    response.headers["Pragma"] = "no-cache"
    return response


@app.route("/")
@login_required
def index():
    """Show portfolio of stocks"""

    # Query for users cash balance
    cash = db.execute("SELECT cash FROM users WHERE id=:id",
                      id=session["user_id"])
    cash = cash[0]["cash"]

    # Query for users owned stocks
    stocks = db.execute(
        "SELECT symbol, name, price, SUM(shares) AS shares, total_price FROM transactions WHERE user_id=:user_id GROUP BY symbol HAVING SUM(shares)>0", user_id=session["user_id"])
    # Set users profit to cash available
    total = cash

    # Find user's stocks worth
    for stock in stocks:
        price = lookup(stock["symbol"])["price"]
        shares = stock["shares"]
        total_price = shares * price
        stock["total_price"] = total_price
        # Add to users profit
        total += total_price

    return render_template("index.html", stocks=stocks, cash=cash, total=total)


@app.route("/buy", methods=["GET", "POST"])
@login_required
def buy():
    """Buy shares of stock"""

    # User reached route via POST
    if request.method == "POST":

        # Ensure symbol was submitted
        if not request.form.get("symbol"):
            return apology("Must provide symbol", 400)

        # Ensure symbol exists
        elif lookup(request.form.get("symbol")) == None:
            return apology("Symbol not found", 400)

        # Ensure shares was submitted
        elif not request.form.get("shares").isdigit():
            return apology("Must provide number of shares", 400)

        # Ensure shares is valid digit
        elif int(request.form.get("shares")) < 1:
            return apology("Must provide valid number of shares", 400)

        # Query for users cash balance
        cash = db.execute(
            "SELECT cash FROM users WHERE id=:id", id=session["user_id"])

        # Lookup stock's price
        stock_price = lookup(request.form.get("symbol"))["price"]

        # Find cost of purchase
        cost = stock_price * int(request.form.get("shares"))

        # Ensure user can afford purchase
        if cash[0]["cash"] < cost:
            return apology("You cannot afford transaction", 400)

        # Update users cash balance
        else:
            db.execute("UPDATE users SET cash = cash - :cost WHERE id=:id",
                       cost=cost, id=session["user_id"])
            # Record purchase
            db.execute("INSERT INTO transactions (user_id, symbol, name, price, shares, total_price) VALUES (:user_id, :symbol, :name, :price, :shares, :total_price)",
                       user_id=session["user_id"], symbol=lookup(request.form.get("symbol"))["symbol"], name=lookup(request.form.get("symbol"))["name"], price=stock_price, shares=int(request.form.get("shares")), total_price=cost)

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET
    else:
        return render_template("buy.html")


@app.route("/history")
@login_required
def history():
    """Show history of transactions"""

    # Query for users owned stocks
    stocks = db.execute(
        "SELECT symbol, price, shares, time FROM transactions WHERE user_id=:user_id", user_id=session["user_id"])

    return render_template("history.html", stocks=stocks)


@app.route("/login", methods=["GET", "POST"])
def login():
    """Log user in"""

    # Forget any user_id
    session.clear()

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("must provide username", 403)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("must provide password", 403)

        # Query database for username
        rows = db.execute("SELECT * FROM users WHERE username = ?",
                          request.form.get("username"))

        # Ensure username exists and password is correct
        if len(rows) != 1 or not check_password_hash(rows[0]["hash"], request.form.get("password")):
            return apology("invalid username and/or password", 403)

        # Remember which user has logged in
        session["user_id"] = rows[0]["id"]

        # Redirect user to home page
        return redirect("/")

    # User reached route via GET (as by clicking a link or via redirect)
    else:
        return render_template("login.html")


@app.route("/logout")
def logout():
    """Log user out"""

    # Forget any user_id
    session.clear()

    # Redirect user to login form
    return redirect("/")


@app.route("/quote", methods=["GET", "POST"])
@login_required
def quote():
    """Get stock quote."""

    # User reached route via POST
    if request.method == "POST":

        # Ensure symbol was submitted
        if not request.form.get("symbol"):
            return apology("Must provide symbol", 400)

        # Use lookup to return stock quote
        stock = lookup(request.form.get("symbol"))

        # Ensure symbol was found
        if not stock:
            return apology("Symbol not found", 400)

        # Return stock quote
        else:
            return render_template("quoted.html", stock=stock)

    # User reached route via GET
    else:
        return render_template("quote.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    """Register user"""

    # User reached route via POST (as by submitting a form via POST)
    if request.method == "POST":

        # Ensure username was submitted
        if not request.form.get("username"):
            return apology("Must provide username", 400)

        # Ensure username is not taken
        elif len(db.execute("SELECT * FROM users WHERE username=:username", username=request.form.get("username"))) != 0:
            return apology("Username unavailable", 400)

        # Ensure password was submitted
        elif not request.form.get("password"):
            return apology("Must provide password", 400)

        # Ensure password meets requirements
        elif len(request.form.get("password")) < 8:
            return apology("Password must be at least 8 characters long", 400)

        elif not any(char.isdigit() for char in request.form.get("password")):
            return apology("Password must contain one number", 400)

        elif not any(char.isupper() for char in request.form.get("password")):
            return apology("Password must contain one uppercase character", 400)

        elif not any(char.isalnum for char in request.form.get("password")):
            return apology("Password must contain one special character", 400)

        # Ensure password was submitted
        elif not request.form.get("confirmation"):
            return apology("Must confirm password", 400)

        # Ensure passwords match
        elif request.form.get("confirmation") != request.form.get("password"):
            return apology("Passwords must match", 400)

        # Hash password
        hash = generate_password_hash(request.form.get("password"))

        # Add user to database
        user = db.execute("INSERT INTO users (username, hash) VALUES (:username,:hash)",
                          username=request.form.get("username"), hash=hash)

        # Remember user
        session["user_id"] = user

        # Rederict user to homepage
        return redirect("/")

    # User reached route via GET
    else:
        return render_template("register.html")


@app.route("/sell", methods=["GET", "POST"])
@login_required
def sell():
    """Sell shares of stock"""

    if request.method == "POST":

        # Ensure stock is selected
        if not request.form.get("symbol"):
            return apology("Must select stock", 400)

        # Ensure user owns stock
        if len(db.execute("SELECT * FROM transactions WHERE user_id=:user_id", user_id=session["user_id"])) == 0:
            return apology("Do not own stock", 400)

        # Ensure shares is submitted
        elif not request.form.get("shares").isdigit():
            return apology("Must provide number of shares", 400)

        # Ensure shares is valid number
        elif int(request.form.get("shares")) < 1:
            return apology("Must provide valid number of shares", 400)

        # Ensure user owns number of shares
        stock_shares = db.execute(
            "SELECT symbol, SUM(shares) AS shares FROM transactions WHERE user_id=:user_id GROUP BY symbol", user_id=session["user_id"])

        if int(request.form.get("shares")) > stock_shares[0]["shares"]:
            return apology("Do not own enough shares")
        else:
            stock_price = lookup(request.form.get("symbol"))["price"]
            cost = stock_price * int(request.form.get("shares"))
            # Update users cash balance
            db.execute("UPDATE users SET cash = cash + :cost WHERE id=:id",
                       cost=cost, id=session["user_id"])
            # Record sell
            db.execute("INSERT INTO transactions (user_id, symbol, name, price, shares, total_price) VALUES (:user_id, :symbol, :name, :price, :shares, :total_price)",
                       user_id=session["user_id"], symbol=lookup(request.form.get("symbol"))["symbol"], name=lookup(request.form.get("symbol"))["name"], price=stock_price, shares=-1*int(request.form.get("shares")), total_price=cost)

        # Redirect user to home page
        return redirect("/")

    else:
        # Allow user to sell from owned stocks
        stocks = db.execute(
            "SELECT symbol, name, price, SUM(shares) AS shares, total_price FROM transactions WHERE user_id=:user_id GROUP BY symbol", user_id=session["user_id"])
        return render_template("sell.html", stocks=stocks)
